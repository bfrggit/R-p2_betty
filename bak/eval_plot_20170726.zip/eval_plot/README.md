Keep plot(s).
