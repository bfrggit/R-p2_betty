Keep result(s) in RData format.
