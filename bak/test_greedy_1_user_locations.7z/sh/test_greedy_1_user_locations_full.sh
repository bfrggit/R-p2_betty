#!/bin/bash

module load R/3.3.2
cd ~/proj/R-p2/
Rscript test_greedy_1_user_locations_full.R
